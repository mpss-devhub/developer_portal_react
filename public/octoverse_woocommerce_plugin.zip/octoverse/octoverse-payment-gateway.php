<?php

/**
 * Plugin Name:       Octoverse Payment Prebuild Form Gateway
 * Plugin URI:        https://mpss.com.mm
 * Description:       Octoverse Payment gateway for woocommerce with prebuild form
 * Version:           1.0
 * Author:            Phyo Khant Kyaw
 * Author URI:        https://mpss.com.mm
 * License:           GPL2
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html 
 * Text Domain:       Octoverse
 * Domain Path:       /languages
 */
require_once 'lib/php-jwt/src/JWT.php';
require_once 'lib/php-jwt/src/Key.php';

use \Firebase\JWT\Key;
use \Firebase\JWT\JWT;

function octoverse_payment_gateway_init()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_Octoverse_Gateway extends WC_Payment_Gateway
    {
        public function __construct()
        {
            $this->id = 'octoverse_payment';
            $this->icon = '';
            $this->has_fields = true;
            $this->method_title = 'Octoverse Payment Gateway';
            $this->method_description = 'Pay securely with Octoverse Payment Gateway.';
            $this->supports = array('products');
            $this->init_form_fields();
            $this->init_settings();
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->enabled = $this->get_option('enabled');
            $this->testmode = 'yes' === $this->get_option('testmode');
            $this->octoverse_payment_url = $this->testmode == 'yes' ? 'https://test.octoverse.com.mm/api/payment/auth/token' : 'https://octoverse.com.mm/api/payment/auth/token';
            $this->octoverse_merchant_id = $this->testmode == 'yes' ? 'MPSSD0000000083' : $this->get_option('octoverse_merchant_id');
            $this->octoverse_secret_key = $this->testmode == 'yes' ? 'JHjRmhCyMAcVGXYuuWyyoy2m_Las8orNUhum60yThQI' : $this->get_option('octoverse_secret_key');
            $this->octoverse_data_key = $this->testmode == 'yes' ? 'XBCENLKT0UC9MQKM' : $this->get_option('octoverse_data_key');
            $this->octoverse_frontend_url = get_bloginfo('url');
            // $this->octoverse_backend_url =  get_bloginfo('url') . '/wc-api/CALLBACK';
            $this->octoverse_backend_url =  "https://mpssuat.glitch.me/octoverse/result";
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
            add_action('woocommerce_api_callback', array($this, 'octoverse_callback'));
        }

        public function init_form_fields()
        {
            $this->form_fields = [
                'enabled' => [
                    'title'   => 'Enable/Disable',
                    'type'    => 'checkbox',
                    'label'   => 'Enable Octoverse Payment Gateway',
                    'default' => 'yes',
                ],
                'title' => [
                    'title'       => 'Title',
                    'type'        => 'text',
                    'description' => 'This controls the title displayed during checkout.',
                    'default'     => 'Octoverse Payment',
                    'desc_tip'    => true,
                ],
                'description' => [
                    'title'       => 'Description',
                    'type'        => 'textarea',
                    'description' => 'This controls the description displayed during checkout.',
                    'default'     => 'Pay securely with Octoverse Payment Gateway.',
                ],
                'testmode' => array(
                    'title'       => 'Test mode',
                    'label'       => 'Enable Test Mode',
                    'type'        => 'checkbox',
                    'description' => 'Payment gateway in test mode will use test API keys.',
                    'default'     => 'yes',
                    'desc_tip'    => true,
                ),
                'octoverse_merchant_id' => array(
                    'title'       => 'Merchant ID',
                    'type'        => 'text'
                ),
                'octoverse_secret_key' => array(
                    'title'       => 'Secret Key',
                    'type'        => 'text'
                ),
                'octoverse_data_key' => array(
                    'title'       => 'Data Key',
                    'type'        => 'text'
                )
            ];
        }

        public function process_payment($order_id)
        {
            $order = wc_get_order($order_id);
            $order->update_status('on-hold', 'Awaiting Octoverse payment.');
            $payload = [
                'merchantID' => $this->octoverse_merchant_id,
                'frontendUrl' => $this->octoverse_frontend_url,
                'backendUrl' => $this->octoverse_backend_url,
                'currencyCode' => get_woocommerce_currency(),
                'amount' => (int) round($order->get_total(), 0),
                'invoiceNo' => strval($order->get_id())
            ];
            $jwt_token = JWT::encode($payload, $this->octoverse_secret_key, 'HS256');
            $payData = ['payData' => $jwt_token];
            $response = wp_remote_post($this->octoverse_payment_url, [
                'method'    => 'POST',
                'body'      => json_encode($payData),
                'headers'   => [
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                ],
            ]);
            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            if (isset($response_body['data'])) {
                $jwt_data_token = $response_body['data'];
                try {
                    $decoded_data = JWT::decode($jwt_data_token, new Key($this->octoverse_secret_key, 'HS256'));
                    if (!empty($decoded_data->paymenturl)) {
                        $redirect_url = $decoded_data->paymenturl;
                        wc_reduce_stock_levels($order_id);
                        WC()->cart->empty_cart();
                        return [
                            'result'   => 'success',
                            'redirect' => $redirect_url,
                        ];
                    } else {
                        throw new Exception('Redirect URL not provided in the JWT payload.');
                    }
                } catch (Exception $e) {
                    wc_add_notice('Payment response error: ' . $e->getMessage(), 'error');
                    return;
                }
            } else {
                wc_add_notice('Payment initialization failed. Please try again or contact support if the issue persists.', 'error');
                return;
            }
        }

        public function octoverse_callback()
        {
            $encrpted_data = file_get_contents("php://input");
            $decoded_data = json_decode($encrpted_data, true); // Decode as an associative array

            if (!isset($decoded_data['data'])) {
                error_log("Missing 'data' field in callback request: " . $encrpted_data);
                return http_response_code(400); // Bad request
            }

            $decrypted_data = openssl_decrypt(base64_decode($decoded_data['data']), 'AES-128-ECB', $this->octoverse_data_key, OPENSSL_RAW_DATA);
            $callbackData = json_decode($decrypted_data);

            if (!$callbackData) {
                error_log("Failed to decode callback JSON: " . $decrypted_data);
                return http_response_code(400);
            }
            global $woocommerce;
            $order = wc_get_order($callbackData->invoiceNo);
            if ($order) {
                $order->add_meta_data('octoverse_p_bank_transactionId', $callbackData->bankTranrefNo);
                $order->add_meta_data('octoverse_p_createdAt', $callbackData->transDateTime);
                $order->add_meta_data('octoverse_p_status', $callbackData->status);
                $order->add_meta_data('octoverse_p_payment_provider', $callbackData->paymentCode);
                $order->save();

                if ($callbackData->status == 'SUCCESS') {
                    $order->payment_complete();
                    $order->update_status('completed');
                    $woocommerce->cart->empty_cart();
                } else {
                    $order->update_status('failed');
                    $woocommerce->cart->empty_cart();
                }
            }
            return http_response_code(200);
        }
    }

    function octoverse_add_gateway_class($gateways)
    {
        $gateways[] = 'WC_Octoverse_Gateway';
        return $gateways;
    }
    add_filter('woocommerce_payment_gateways', 'octoverse_add_gateway_class');
}

add_action('plugins_loaded', 'octoverse_payment_gateway_init', 11);

function octoverse_register_checkout_block($payment_gateways)
{
    $payment_gateways['octoverse_payment'] = [
        'label'   => 'Octoverse Payment',
        'gateway' => 'WC_Octoverse_Gateway',
    ];
    return $payment_gateways;
}

add_filter('woocommerce_blocks_payment_gateways', 'octoverse_register_checkout_block');
